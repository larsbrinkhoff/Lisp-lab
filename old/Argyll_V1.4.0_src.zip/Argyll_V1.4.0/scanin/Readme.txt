
This directory contains the code to extract charts from
TIFF scan files, and output the patch values using the
CGATS file format. Typically this is used to get the
patch information from a scan of an IT8 calibration
chart.

scanin.exe	processes a TIFF file into a CGATS file.
