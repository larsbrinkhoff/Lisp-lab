A simple Windows NT/X11 2d graph plot library,
to quickly display graphs and points for debug purposes.
