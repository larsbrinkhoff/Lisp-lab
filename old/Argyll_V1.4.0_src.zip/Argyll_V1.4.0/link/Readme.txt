This direcory holds the top level icc link code.

collink.exe	takes two device ICC profiles, and links
			then together in a simple fashion, producing
			a device link ICC profile.

