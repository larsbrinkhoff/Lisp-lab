This direcory holds general profile and device link
tweaking, refining & adjustment code.

refine	allows the colorimetric B2A table of a profile to be refined
		in the light of target and measured patch values.
