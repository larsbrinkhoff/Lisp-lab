
2D Raster rendering support.
---------------------------

This is a very simple 2D rendering library, intended to
support test and verification chart generation, and
raster color test chart creation. Speed is not
an objective of this library, just simplicity.


